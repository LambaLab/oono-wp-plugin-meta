<?php
// include/oonoFuncations.php

class oonoFuncations {

    public function __construct() {
        // Constructor logic if necessary
    }
    public function get_active_theme_screenshot() {
    $theme = wp_get_theme();  // Get current active theme object
    $theme_directory = $theme->get_stylesheet_directory();  // Get theme's directory path
    $screenshot_path = $theme_directory . '/screenshot.png';  // Path to screenshot

    if (file_exists($screenshot_path)) {
        // Get the URL of the screenshot
        $screenshot_url = get_theme_file_uri('screenshot.png');
        return $screenshot_url;
    } else {
        // Default fallback if screenshot doesn't exist
        return 'https://via.placeholder.com/300x200?text=No+Screenshot+Available';
    }
}

}