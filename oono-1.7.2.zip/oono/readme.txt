== Changelog ==
= 1.5.0 =
- Brand validation.
- Improment and modifications.

= 1.0.0 =
- Initial release.
