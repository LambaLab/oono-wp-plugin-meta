<?php
/*
Plugin Name: oono
Description: A plugin to connect brands via API and display/manage their stories in WordPress.
Version: 1.3.0
Author: oono dev team
*/

global $oono_version;
$oono_version = '1.3.0';

// Plugin update check
function my_plugin_check_for_updates($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $plugin_slug = 'oono/oono-am.php'; // Adjust for your plugin's file path
    $current_version = get_option('oono_version');

    $response = wp_remote_get('https://raw.githubusercontent.com/LambaLab/oono-wp-plugin-meta/refs/heads/main/plugin-update.json');
    if (is_wp_error($response)) {
        return $transient;
    }

    $update_info = json_decode(wp_remote_retrieve_body($response), true);

    if (version_compare($current_version, $update_info['version'], '<')) {
        $transient->response[$plugin_slug] = (object) [
            'slug' => 'my-plugin',
            'new_version' => $update_info['version'],
            'url' => 'https://github.com/LambaLab/oono-wp-plugin-meta',
            'package' => $update_info['download_url']
        ];
    }
    return $transient;
}
add_filter('site_transient_update_plugins', 'my_plugin_check_for_updates');


// Update database after plugin update
function my_plugin_update_version($upgrader_object, $options) {
    if ($options['action'] === 'update' && $options['type'] === 'plugin') {
        $updated_plugins = $options['plugins'];
        $plugin_slug = 'oono/oono-am.php'; // Adjust this

        if (in_array($plugin_slug, $updated_plugins)) {
            $response = wp_remote_get('https://raw.githubusercontent.com/LambaLab/oono-wp-plugin-meta/refs/heads/main/plugin-update.json');
            if (!is_wp_error($response)) {
                $update_info = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($update_info['version'])) {
                    update_option('oono_version', $update_info['version']);
                }
            }
        }
    }
}
add_action('upgrader_process_complete', 'my_plugin_update_version', 10, 2);


// Include the DataFeeds class from the include folder
require_once plugin_dir_path(__FILE__) . 'include/DataFeeds.php';

// Include the DataFeeds class from the include folder
require_once plugin_dir_path(__FILE__) . 'include/oonoFuncations.php';

// Activation hook: Create necessary tables on plugin activation
register_activation_hook(__FILE__, 'oono_plugin_activation');

function oono_plugin_activation()
{
    global $oono_version;
   // delete_option('oono_version');
    update_option('oono_version', $oono_version);
    DataFeeds::create_oono_tables();
}

// Hook to run when the plugin is deactivated
register_deactivation_hook(__FILE__, 'oono_plugin_deactivation_cleanup');

function oono_plugin_deactivation_cleanup()
{
    if (get_option('oono_brand_id') !== false) {
        delete_option('oono_brand_id');
    }
    if (get_option('oono_brand_access_key') !== false) {
        delete_option('oono_brand_access_key');
    }
}

// Uninstall hook: Drop the tables when the plugin is deleted
register_uninstall_hook(__FILE__, 'oono_delete_plugin_tables');
function oono_delete_plugin_tables()
{

    DataFeeds::delete_oono_tables();
    // Remove option of active brand.
    if (get_option('oono_brand_id') !== false) {
        delete_option('oono_brand_id');
    }
    if (get_option('oono_brand_access_key') !== false) {
        delete_option('oono_brand_access_key');
    }
}

// Handle API request and save data
function oono_fetch_and_save_brand_data($access_key)
{

    $dataFeeds = new DataFeeds();
    return $dataFeeds->fetch_and_save_brand_data($access_key);
}
// Handle API request and save data
function oono_archive_brand_data($oono_brand_id)
{

    $dataFeeds = new DataFeeds();
    $dataFeeds->archive_brand_data($oono_brand_id);
    if (get_option('oono_brand_id') !== false) {
        delete_option('oono_brand_id');
    }
    if (get_option('oono_brand_access_key') !== false) {
        delete_option('oono_brand_access_key');
    }

    return true;
}
// Admin menu page
add_action('admin_menu', 'oono_create_menu');
function oono_create_menu()
{
    add_menu_page('oono', 'oono', 'manage_options', 'oono-brand-connector', 'oono_brand_settings_page');
}

function oono_enqueue_admin_styles()
{
    wp_enqueue_style(
        'oono-admin-style', // Handle for the stylesheet
        plugin_dir_url(__FILE__) . 'css/style.css',
        [], // Dependencies (if any)
        '1.0.0' // Version number
    );
}
add_action('admin_enqueue_scripts', 'oono_enqueue_admin_styles');


function oono_brand_settings_page()
{
  $current_version = get_option('oono_version');
?>
    <div class="wrap">
        <h1>oono (version <?php echo $current_version; ?>)</h1>


        <!-- Main Container with Two Columns -->
        <div class="brand-info-section  brand-info-container">
            <!-- Left Block -->
            <div class="left-block">
                <h2>Brand Connection</h2>
                <div class="brand-info">
                    <!-- Brand Access Key Form -->
                    <?php


                    // Handle form submission and fetch brand data
                    if (isset($_POST['submit'])) {
                        $access_key = sanitize_text_field($_POST['brand_access_key']);
                        $submit_value = sanitize_text_field($_POST['submit']);
                        $oono_brand_id = sanitize_text_field($_POST['submit']);

                        // Store the access key in the options table
                        update_option('oono_brand_access_key', $access_key);

                        if ($submit_value == "Connect Brand" && oono_fetch_and_save_brand_data($access_key)) {
                            echo '<p>Brand data fetched and saved successfully!</p>';
                        } elseif ($submit_value == "Remove Brand" && oono_fetch_and_save_brand_data($access_key)) {
                            oono_archive_brand_data(get_option('oono_brand_id'));
                            echo '<p>Brand Removed.</p>';
                        } else {

                            echo '<p>Error fetching brand data. Please try again.</p>';
                        }
                    }

                    // Retrieve the stored brand_access_key
                    $stored_access_key = get_option('oono_brand_access_key', '');
                    $oono_brand_id = get_option('oono_brand_id');
                    ?>
                    <form method="post" action="">
                        <div class="form-group">
                            <label for="brand-access-key">Brand Access Key:</label>
                        </div>
                        <div class="form-group">
                            <input type="text" id="brand-access-key" name="brand_access_key" value="<?php echo esc_attr($stored_access_key); ?>" <?php if (!empty($oono_brand_id)) {
                                                                                                                                                        echo "readonly";
                                                                                                                                                    } ?> required>
                        </div>
                        <input type="submit" name="submit" class="button-primary <?php if (!empty($oono_brand_id)) { ?> remove-button <?php } ?>" <?php if (!empty($oono_brand_id)) { ?>onclick="return confirmRemoveBrand();" value="Remove Brand" <?php } else { ?> value="Connect Brand" <?php } ?>>
                    </form>
                </div>
                <?php if (!empty($stored_access_key)) { ?>
                    <div class="refresh-button" id="refreshButton">
                        <i id="rotate-icon" class="fas fa-sync-alt"></i> Refresh
                    </div>

                    <div id="resultContainer">
                        <!-- AJAX content will be loaded here -->
                    </div>
                <?php } ?>
            </div>
            <?php
            // Display Brand Information
            oono_display_brand_information();

            // Fetch brand data to get the brand ID
            global $wpdb;
            $brands_table = $wpdb->prefix . 'oono_brands';

            $oono_brand_id = get_option('oono_brand_id');
            // Get brand data from the table
            $brand = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $brands_table WHERE brandId = %s", $oono_brand_id)
            );


            if ($brand) {
                // Display Collection Information for the brand
                oono_display_collection_information($brand->id);
            } else {
            ?>
        </div>
        <div class="collections-info-section">
            <h2>Embed Details</h2>

            <?php $collection_sekelton = plugins_url('images/collection-sekelton.png', __FILE__); // Adjust the path as needed 
            ?>
            <img src="<?php echo esc_url($collection_sekelton); ?>" class="coll-skl-block-img">

        </div>
    <?php
            }
    ?>
    </div>
    <?php
}

// Function to display brand information
function oono_display_brand_information()
{

    $oono_brand_id = get_option('oono_brand_id');
    $dataFeeds = new DataFeeds();
    $brand =  $dataFeeds->getBrand($oono_brand_id);


    if ($brand) {

        $dataFeeds = new DataFeeds();
        $collection_count =  $dataFeeds->getCollectionCount($brand->id);


    ?>

        <!-- Right Block -->
        <div class="right-block">
            <div class="brand-info-header">
                <h2>Brand Information</h2>

                <div class="toggle-switch">
                    <label class="toggle-text">Enable/Disable </label>
                    <input type="checkbox" id="toggle-checkbox" class="toggle-checkbox" <?php checked($brand->wp_internal_brand_status, true); ?> data-brand-id="<?php echo esc_attr($brand->id); ?>">
                    <label for="toggle-checkbox" class="toggle-label">
                        <span class="toggle-inner"></span>
                        <span class="toggle-switch-button"></span>
                    </label>

                </div>


            </div>
            <div class="brand-info">
                <?php
                $logo_url = esc_url($brand->logo);
                $default_logo_url = plugins_url('images/default-logo.png', __FILE__); // Adjust the path as needed

                // Check if the logo URL is valid and exists
                if (filter_var($logo_url, FILTER_VALIDATE_URL) && @getimagesize($logo_url)) {
                    // Logo exists
                    $img_src = $logo_url;
                } else {
                    // Logo does not exist, use default logo
                    $img_src = $default_logo_url;
                }

                if ($brand->wp_internal_brand_status == 1) {
                    $pugin_status_class = "active";
                    $pugin_status = "Enabled";
                } else {
                    $pugin_status_class = "in-active";
                    $pugin_status =  "Disabled (No more stories visible on your website)";
                }
                ?>

                <img src="<?php echo esc_url($img_src); ?>" alt="<?php echo esc_attr($brand->name); ?> logo" class="brand-logo round-logo">
                <!-- <p class="brand-name"><strong>Brand Name:</strong> <?php // echo esc_html($brand->name); 
                                                                        ?></p> -->

                <div class="brand-detail">
                    <span class="label"><strong>Brand Name:</strong></span>
                    <span class="value" id="oono_brand_name"><?php echo esc_html($brand->name); ?></span>
                </div>

                <div class="brand-detail">
                    <span class="label"><strong>Slug:</strong></span>
                    <span class="value"><?php echo esc_html($brand->slug); ?></span>
                </div>
                <div class="brand-detail">
                    <span class="label"><strong>Collections Count:</strong></span>
                    <span class="value" id="oono_brand_collectionCount" data-value="<?php echo esc_attr($collection_count); ?>"><?php echo esc_html($collection_count); ?></span>
                </div>
                <div class="brand-detail">
                    <span class="label"><strong>Stories Count:</strong></span>
                    <span class="value" id="oono_brand_storiesCount"><?php echo esc_html($brand->storiesCount); ?></span>
                </div>

                <div class="brand-detail">
                    <span class="label"><strong>Plugin Enable / Disable:</strong></span>
                    <span id="pugin-status" class="value <?php echo $pugin_status_class; ?>"><?php echo $pugin_status; ?></span>
                </div>

                <div class="brand-detail">
                    <span class="value in-active" id="oono_brand_status"><?php if (esc_html($brand->status) != "ACTIVE") {
                                                                                echo "*This brand is in-active by oono. Please connect to oono help.";
                                                                            } ?></span>
                </div>

            </div>



        </div>
        </div>
    <?php
    } else {

        $brand_sekelton = plugins_url('images/brand-sekelton.png', __FILE__); // Adjust the path as needed
    ?>
        <div class="right-block">
            <img src="<?php echo esc_url($brand_sekelton); ?>" class="right-block-img">
        </div>
    <?php
    }
}
// Handle enabling/disabling brand status
if (isset($_POST['toggle_brand'])) {
    $brand_id = intval($_POST['toggle_brand_status']);
    $current_status = $wpdb->get_var($wpdb->prepare("SELECT wp_internal_brand_status FROM {$wpdb->prefix}oono_brands WHERE id = %d", $brand_id));

    // Toggle the brand status
    $new_status = ($current_status == true) ? false : true;
    $wpdb->update(
        $wpdb->prefix . 'oono_brands',
        ['wp_internal_brand_status' => $new_status],
        ['id' => $brand_id]
    );

    // Redirect to avoid form re-submission issues
    wp_redirect(admin_url('admin.php?page=oono-brand-connector'));
    exit;
}
// Function to display collection information
function oono_display_collection_information($brand_id)
{
    ?>
    <div class="collections-info-section">
        <h2>Embed Details</h2>
        <div class="tabs">
            <?php
            global $wpdb;
            $collections_table = $wpdb->prefix . 'oono_brands_collections';
            $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';
            $oono_carousels_table = $wpdb->prefix . 'oono_carousels';

            // Get collections associated with the brand
            $collections = $wpdb->get_results($wpdb->prepare("SELECT * FROM $collections_table WHERE wp_oono_brand_id = %d", $brand_id));

            // Get collections associated with the brand
            $carousels = $wpdb->get_results($wpdb->prepare("SELECT * FROM $oono_carousels_table WHERE wp_oono_brand_id = %d", $brand_id));

            ?>
            <!-- Tab Links -->
            <ul class="tab-links">
                <?php
                $icon_update_active = !empty($_GET['icon-update']);
                ?>

                <li class="<?php echo !$icon_update_active ? 'active' : ''; ?>">
                    <a href="#dev-container-1">Collections (<?php echo !empty($collections) ? count($collections) : 0; ?>)</a>
                </li>
                <li>
                    <a href="#dev-container-2">Carousels (<?php echo !empty($carousels) ? count($carousels) : 0; ?>)</a>
                </li>
                <li class="<?php echo $icon_update_active ? 'active' : ''; ?>">
                    <a href="#dev-container-3">Icon</a>
                </li>
            </ul>
            <div class="gray_line"></div>
            <!-- Tab Content -->
            <div class="tab-content">
                <div id="dev-container-1" class="tab-pane <?php echo !$icon_update_active ? 'active' : ''; ?>">

                    <?php
                    if (!empty($collections)) {
                        foreach ($collections as $collection) :
                    ?>

                            <div class="collection-info" id="section-<?php echo esc_attr($collection->collectionId); ?>">

                                <div class="collection-details">


                                    <div id="oono-stories-container" data-config='{"collectionId": "<?php echo esc_attr($collection->collectionId); ?>", "brandId": "<?php echo esc_attr($collection->brandSlug); ?>", "storyId": 1, "type": "inPage", "style":{"width":"100px","height":"200px","borderRadius":"8px"}}'></div>

                                    <div class="collection-info-p">
                                        <p><strong>Collection Name:</strong> <span id="oono_collection_name_<?php echo esc_html($collection->collectionId); ?>"><?php echo esc_html($collection->name); ?></span></p>

                                        <p><strong>Stories Count:</strong> <span id="oono_collection_storiesCount_<?php echo esc_html($collection->collectionId); ?>"><?php echo esc_html($collection->storiesCount); ?></span></p>

                                        <?php
                                        // Show Enable/Disable button based on collection status
                                        $collection_current_status = ($collection->wp_internal_collection_status) ? 'Enabled' : 'Disabled';
                                        $collection_button_label = ($collection->wp_internal_collection_status) ? 'Disable Collection' : 'Enable Collection';
                                        $collection_status_oono = ($collection->status == "ACTIVE") ? '' : 'in-active';
                                        $collection_status_class = ($collection->wp_internal_collection_status) ? 'active' : 'in-active';
                                        ?>

                                        <p><strong>WP Status:</strong> <span class="<?php echo  $collection_status_class; ?>"><?php echo esc_html($collection_current_status); ?></span></p>
                                        <form method="post" action="<?php echo plugin_dir_url(__FILE__) . 'include/actions.php'; ?>">
                                            <input type="hidden" name="toggle_collection_status" value="<?php echo esc_attr($collection->id); ?>">
                                            <input type="hidden" name="collection_current_status" value="<?php echo esc_attr($collection->wp_internal_collection_status); ?>">
                                            <input type="submit" name="toggle_collection" value="<?php echo esc_attr($collection_button_label); ?>" class="button-secondary">
                                        </form>
                                        <p><span class="<?php echo $collection_status_oono; ?> in-active" id="oono_collection_status_<?php echo esc_html($collection->collectionId); ?>"><?php if ($collection->status != "ACTIVE") {
                                                                                                                                                                                                echo "* This collection is in-active by oono. Please contact to oono help.";
                                                                                                                                                                                            } ?></span></p>

                                        <p><span class="in-active" id="oono_collection_type_<?php echo esc_html($collection->collectionId); ?>"><?php if ($collection->type == "PRIVATE") {
                                                                                                                                                    echo "* This collection is private on oono and will not be visible on your website for now.";
                                                                                                                                                } ?></span></p>


                                    </div>
                                </div>

                                <div class="embed-section">
                                    <!-- Button Short Code Section -->
                                    <h3>Get Button Shortcode For Your Page/Post</h3>
                                    <div class="shortcode-display">
                                        <div class="copy-icon-wrapper">
                                            <code id="shortcode-text-button<?php echo esc_attr($collection->id); ?>">[oono_button collection_id="<?php echo esc_attr($collection->collectionId); ?>"]</code>
                                            <div class="copy-icon" data-values='{"collectionId":<?php echo esc_attr($collection->id); ?>,"copyElement":"button"}'><i class="fas fa-copy"></i></div>
                                        </div>
                                    </div>

                                    <!-- Collection Cover Embed Section -->
                                    <div class="cover-settings-header">
                                        <h3>Get Collection Cover For Your Page/Post</h3>
                                    </div>
                                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

                                    <div class="shortcode-display">

                                        <div class="copy-icon-wrapper">
                                            <code id="shortcode-text-cover<?php echo esc_attr($collection->id); ?>">[oono_collection_cover collection_id="<?php echo esc_attr($collection->collectionId); ?>"]</code>
                                            <div class="copy-icon" data-values='{"collectionId":<?php echo esc_attr($collection->id); ?>,"copyElement":"cover"}'><i class="fas fa-copy"></i></div>
                                        </div>

                                        <?php

                                        $embed_setting = $wpdb->get_row($wpdb->prepare(
                                            "SELECT * FROM $embed_settings_table WHERE collectionId = %s AND type = %s",
                                            $collection->collectionId,
                                            'inPage'
                                        ));

                                        // Decode the style JSON
                                        $cover_style = json_decode($embed_setting->style, true);
                                        $width = isset($cover_style['width']) ? $cover_style['width'] : '255px';
                                        $height = isset($cover_style['height']) ? $cover_style['height'] : 'auto';
                                        $borderRadius = isset($cover_style['borderRadius']) ? $cover_style['borderRadius'] : '8px';
                                        $type = $embed_setting->type;

                                        ?>

                                        <div class="cover-dimensions-row">
                                            <p><strong>Width:</strong> <span class="hw-number"><?php echo $width; ?>,</span>
                                                <strong>Height:</strong> <span class="hw-number"><?php echo $height; ?></span>
                                            </p>
                                            <div class="cover-size-settings-button" id="open-cover-settings-<?php echo esc_attr($collection->id); ?>">⚙️</div>
                                        </div>

                                        <div class="cover-size-settings" id="cover-size-settings-<?php echo esc_attr($collection->id); ?>" style="display: none;">
                                            <form method="post" class="settings-form" action="<?php echo plugin_dir_url(__FILE__) . 'include/actions.php'; ?>">
                                                <div class="form-group">
                                                    <label for="width_<?php echo esc_attr($collection->id); ?>">Width:</label>
                                                    <input type="text" name="width" id="width_<?php echo esc_attr($collection->id); ?>" value="<?php echo $width; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="height_<?php echo esc_attr($collection->id); ?>">Height:</label>
                                                    <input type="text" name="height" id="height_<?php echo esc_attr($collection->id); ?>" value="<?php echo $height; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="height_<?php echo esc_attr($collection->id); ?>">borderRadius:</label>
                                                    <input type="text" name="borderRadius" id="borderRadius_<?php echo esc_attr($collection->id); ?>" value="<?php echo $borderRadius; ?>" required>
                                                </div>
                                                <input type="hidden" name="collection_id" value="<?php echo esc_attr($collection->collectionId); ?>">
                                                <input type="hidden" name="brandSlug" value="<?php echo esc_attr($collection->brandSlug); ?>">
                                                <input type="hidden" name="type" value="<?php echo esc_attr($type); ?>">
                                                <div class="form-actions">
                                                    <input type="submit" name="save_cover_settings" value="Save Cover Settings" class="button-primary">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                // $embed_setting = $wpdb->get_row($wpdb->prepare(
                                //     "SELECT * FROM $embed_settings_table WHERE collectionId = %s AND type = %s",
                                //     $collection->collectionId,
                                //     'floating'
                                // ));

                                // // Retrieve stored values
                                // $type = $embed_setting->type;
                                // $position = $embed_setting->position;
                                // $positionType = $embed_setting->positionType;
                                // $status = $embed_setting->status;
                                ?>
                            </div>

                    <?php
                        endforeach;
                    } else {
                        echo '<p>No collections found for this brand.</p>';
                    }
                    ?>
                </div>
                <div id="dev-container-2" class="tab-pane">

                    <?php

                    if (!empty($carousels)) {

                        foreach ($carousels as $carousel) :
                    ?>
                            <div class="collection-info">
                                <div class="collection-carousel">

                                    <div id="oono-stories-container" data-config='{"carouselId":"<?php echo esc_attr($carousel->carousal_key); ?>"}'></div>
                                </div>
                                <div class="collection-carousel_right">
                                    <p><strong>Carousel Title:</strong> <span><?php echo esc_html($carousel->title); ?></span></p>
                                    <p><strong>Collection Counts:</strong> <span><?php echo esc_html($carousel->collection_counts); ?></span></p>
                                    <?php
                                    $carousel_status_oono = ($carousel->enabled == 1) ? '' : 'in-active';
                                    $carousel_status_class = ($carousel->wp_internal_carousel_status == 1) ? 'active' : 'in-active';
                                    ?>
                                    <p><strong>WP Status:</strong> <span class="<?php echo  $carousel_status_class; ?>"><?php echo esc_html($carousel_status_class); ?></span></p>

                                    <p><span class="<?php echo $carousel_status_oono; ?> in-active" id="oono_carousel_status_<?php echo esc_html($carousel->enabled); ?>"><?php if ($carousel->enabled != 1) {
                                                                                                                                                                                echo "* This carousel may not be available because it has been disabled by Oono Admin.";
                                                                                                                                                                            } ?></span></p>


                                    <div class="copy-icon-wrapper shortcode-display">
                                        <code id="shortcode-text-carousel<?php echo esc_attr($carousel->id); ?>">[oono_carousel carousel_key="<?php echo esc_attr($carousel->carousal_key); ?>"]</code>
                                        <div class="copy-icon" data-values='{"carousel_id":<?php echo esc_attr($carousel->id); ?>,"copyElement":"carousel"}'><i class="fas fa-copy"></i></div>
                                    </div>

                                </div>
                            </div>
                    <?php endforeach;
                    }
                    ?>
                </div>
                <div id="dev-container-3" class="tab-pane <?php echo $icon_update_active ? 'active' : ''; ?>">

                    <div class="icon-info" id="section-icon<?php echo esc_attr($collection->collectionId); ?>">
                        <form method="post" action="<?php echo plugin_dir_url(__FILE__) . 'include/actions.php'; ?>" id="float-settings-form" class="settings-form float-settings-form">


                            <?php
                            $embed_setting = $wpdb->get_row($wpdb->prepare(
                                "SELECT * FROM $embed_settings_table WHERE type = %s and wp_oono_brand_id = %s",
                                'floating',
                                $brand_id

                            ));

                            // Retrieve stored values
                            $settings_Id = null;
                            $settings_collectionId = null;
                            $type =  'floating';
                            $position = 'bottom-right';
                            $positionType =  'float';
                            $status =  0;
                            $wp_oono_brand_id = '';
                            $wp_oono_collection_id = '';
                            $brandSlug = '';

                            if (!empty($embed_setting)) {
                                $settings_Id = $embed_setting->id;
                                $settings_collectionId = $embed_setting->collectionId;
                                $type = $embed_setting->type;
                                $position = $embed_setting->position;
                                $positionType = $embed_setting->positionType;
                                $status = $embed_setting->status;

                                $wp_oono_brand_id = $embed_setting->wp_oono_brand_id;
                                $wp_oono_collection_id = $embed_setting->wp_oono_collection_id;
                                $brandSlug = $embed_setting->brandSlug;
                            }
                            if (empty($wp_oono_brand_id)) {
                                $wp_oono_brand_id = $brand_id;
                            }
                            ?>
                            <div class="float-section">
                                <div class="screenshot-wrapper">
                                    <div style="width:300px">
                                        <div class="form-group full-width border-line">
                                            <h3>Icon Settings</h3>
                                        </div>

                                        <!-- Hidden Form for Updating Settings -->
                                        <div class="floating-settings" id="floating-settings-icon" ;>
                                            <div class="form-group">
                                                <label for="position">Position:</label>
                                                <select name="position" class="postionOfFloating" data-values='{"collectionId":<?php echo esc_attr($collection->id); ?>}'>
                                                    <option value="top-right" <?php selected($position, 'top-right'); ?>>Top Right</option>
                                                    <option value="bottom-right" <?php selected($position, 'bottom-right'); ?>>Bottom Right</option>
                                                    <option value="top-left" <?php selected($position, 'top-left'); ?>>Top Left</option>
                                                    <option value="bottom-left" <?php selected($position, 'bottom-left'); ?>>Bottom Left</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="positionType">Type:</label>
                                                <select name="positionType" id="positionType">
                                                    <option value="fix" <?php selected($positionType, 'fix'); ?>>Fixed</option>
                                                    <option value="float" <?php selected($positionType, 'float'); ?>>Floating</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="status">Status:</label>
                                                <select name="status" id="status" class="floatingStatus" data-values='{"collectionId":<?php echo esc_attr($collection->id); ?>}'>
                                                    <option value="1" <?php selected($status, '1'); ?>>Enabled</option>
                                                    <option value="0" <?php selected($status, '0'); ?>>Disabled</option>
                                                </select>
                                            </div>
                                            <input type="hidden" name="settings_Id" id="floating-settings_Id" value="<?php echo $settings_Id; ?>" style="width: 200px;">

                                            <input type="hidden" name="wp_oono_brand_id" id="floating-oono_brand_id" value="<?php echo $wp_oono_brand_id; ?>" style="width: 200px;">
                                            <input type="hidden" name="wp_oono_collection_id" id="floating-wp_oono_collection_id" value="<?php echo $wp_oono_collection_id; ?>" style="width: 200px;">
                                            <input type="hidden" name="collection_id" id="floating-collectionId" value="<?php echo $settings_collectionId; ?>" style="width: 200px;">
                                            <input type="hidden" name="brandSlug" id="floating-brandSlug" value="<?php echo $brandSlug; ?>" style="width: 200px;">
                                            <input type="hidden" name="type" value="<?php echo esc_attr($type); ?>" style="width: 200px;">

                                        </div>

                                    </div>
                                    <?php
                                    $oonoFuncations = new oonoFuncations();
                                    $screenshot_url = $oonoFuncations->get_active_theme_screenshot();

                                    ?>
                                    <div class="theme-screenshot-container" style="background-image: url('<?php echo $screenshot_url; ?>')" ;>
                                        <!-- Floating Icons -->
                                        <div class="theme-screenshot-container-inner">
                                        </div>
                                        <div id="floatingIcon-icon" class="ring <?php echo esc_html($position); ?> <?php if ($status == 0) {
                                                                                                                        echo "display-none";
                                                                                                                    } ?>">
                                            <div class="ring-iiner">
                                                <img src="https://staging-apis-v2.oono.ai/media/avatar/default.png" width="25px" height="25px">
                                                <div id="floating-disabled-icon" class="<?php if ($status == 0) {
                                                                                            echo "ring-iiner2";
                                                                                        } ?>"></div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="collection-details-icon">
                                <div class="image-grid">
                                    <div class="form-group full-width border-line">
                                        <h2 style="font-size: 1.2em;">Select a collection:</h2>
                                    </div>
                                    <?php

                                    if (!empty($collections)) {
                                        foreach ($collections as $collection) :

                                            // if (empty($settings_collectionId)) {
                                            //     $settings_collectionId = $collection->collectionId;
                                            //     $wp_oono_brand_id = $collection->wp_oono_brand_id;
                                            //     $wp_oono_collection_id = $collection->id;
                                            //     $brandSlug = $collection->brandSlug;
                                            // }
                                    ?>
                                            <div class="image-card <?php if (!empty($settings_collectionId) and $settings_collectionId == $collection->collectionId) {
                                                                        echo "selected";
                                                                    } ?>" data-values='{"wp_oono_collection_id":"<?php echo esc_attr($collection->id); ?>","collectionId":"<?php echo esc_attr($collection->collectionId); ?>","wp_oono_brand_id":"<?php echo esc_attr($collection->wp_oono_brand_id); ?>","brandSlug":"<?php echo esc_attr($collection->brandSlug); ?>"}'>
                                                <div class="image-container">
                                                    <img src="<?php echo  !empty($collection->thumbnail) ? $collection->thumbnail : 'https://media.oono.ai/uploads/' . $collection->cover; ?>" alt="<?php echo esc_attr($collection->name);  ?>" width="140" alt="Serene Landscape">
                                                </div>
                                                <div class="image-title-container">
                                                    <h3 class="image-title"><?php echo $collection->name; ?></h3>
                                                </div>
                                            </div>

                                        <?php
                                        endforeach;
                                        ?>

                                    <?php
                                    } else {
                                        echo '<p>No collections found for icon to enable.</p>';
                                    }
                                    ?>
                                </div>

                            </div>
                            <div class="form-group" style="width: 24%;     padding: 0 0 12px 25px;">

                                <input type="submit" name="save_float_settings" value="Update Settings" class="button-primary">
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!-- Floating message -->
        <div id="copy-message">Copied!</div>
    </div>
<?php

}

add_action('admin_enqueue_scripts', 'load_custom_admin_scripts');
function load_custom_admin_scripts()
{
    wp_enqueue_script('jquery'); // Ensure jQuery loads
    wp_enqueue_script('custom-script', plugin_dir_url(__FILE__) . 'js/scripts.js', ['jquery'], false, true);
}


// Register Shortcode
add_shortcode('oono_button', 'oono_stories_shortcode');

function oono_stories_shortcode($atts)
{


    // Define default attributes
    $atts = shortcode_atts([
        'collection_id' => '',
    ], $atts, 'oono_stories');


    $dataFeeds = new DataFeeds();
    $embed_setting =  $dataFeeds->fetch_embed_setting($atts, 'button');




    // If no settings found, return an empty string or a message
    if (!$embed_setting) {
        return false;
    }

    $brandSlug = $embed_setting->brandSlug;

    // Return the HTML for displaying the cover

    ob_start();

?>
    <div id="oono-stories-container" data-config='{"collectionId":  "<?php echo esc_attr($atts['collection_id']); ?>", "brandId": "<?php echo esc_attr($brandSlug); ?>", "storyId": 1, "type": "button"}'></div>
<?php
    return ob_get_clean();
}
// Register Shortcode
add_shortcode('oono_collection_cover', 'oono_cover_shortcode');

function oono_cover_shortcode($atts)
{


    // Define default attributes
    $atts = shortcode_atts([
        'collection_id' => '',
    ], $atts, 'oono_cover');

    $dataFeeds = new DataFeeds();
    $embed_setting =  $dataFeeds->fetch_embed_setting($atts, 'inPage');

    // If no settings found, return an empty string or a message
    if (!$embed_setting) {
        return false;
    }

    $brandSlug = $embed_setting->brandSlug;

    // Decode the style JSON
    $cover_style = json_decode($embed_setting->style, true);
    $width = isset($cover_style['width']) ? $cover_style['width'] : '255px';
    $height = isset($cover_style['height']) ? $cover_style['height'] : 'auto';
    $borderRadius = isset($cover_style['borderRadius']) ? $cover_style['borderRadius'] : '8px';

    // Return the HTML for displaying the cover

    ob_start();

?>
    <div id="oono-stories-container" data-config='{
        "collectionId": "<?php echo esc_attr($atts['collection_id']); ?>",
        "brandId": "<?php echo esc_attr($brandSlug); ?>",
        "storyId": 1,
        "type": "inPage",
        "style": {
            "width": "<?php echo esc_attr($width); ?>",
            "height": "<?php echo esc_attr($height); ?>",
            "borderRadius": "<?php echo esc_attr($borderRadius); ?>"
        }
    }'></div>
    <?php
    return ob_get_clean();
}

// Register Shortcode carsel
add_shortcode('oono_carousel', 'oono_carousel_shortcode');

function oono_carousel_shortcode($atts)
{


    // Define default attributes
    $atts = shortcode_atts([
        'carousel_key' => '',
    ], $atts, 'oono_carousel');

    $dataFeeds = new DataFeeds();
    $carousel =  $dataFeeds->fetch_carousel($atts);


    ob_start();
    if (!empty($carousel->carousal_key)) {
    ?>
        <div id="oono-stories-container" data-config='{"carouselId":"<?php echo esc_attr($carousel->carousal_key); ?>"}'></div>
    <?php
    }
    return ob_get_clean();
}

function my_plugin_insert_embed_settings_footer()
{


    $dataFeeds = new DataFeeds();
    $embed_settings =  $dataFeeds->fetch_embed_setting(null, 'floating');

    // Buffer output
    ob_start();

    //var_dump($embed_settings);

    // Loop through each embed setting and output a <div> with dynamic data-config
    foreach ($embed_settings as $embed_setting) {
    ?>
        <div id="oono-stories-container" data-config='<?php echo json_encode([
                                                            'collectionId' => $embed_setting->collectionId,
                                                            'brandId' => $embed_setting->brandSlug,  // Assuming brandSlug is the brand ID
                                                            'storyId' => 1,  // Replace with dynamic story ID if available
                                                            'type' => $embed_setting->type,
                                                            'position' => $embed_setting->position,  // Replace with dynamic position if available
                                                            'positionType' => $embed_setting->positionType,
                                                        ]); ?>'></div>
    <?php
    }

    // Return the buffered output
    echo ob_get_clean();
}

// Hook into the wp_footer action to insert the embed settings div into the footer
add_action('wp_footer', 'my_plugin_insert_embed_settings_footer');
// Function to enqueue the footer script
function oono_enqueue_footer_script()
{
    global $wpdb;

    // Check if the brand is active and has a valid status
    $brand = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}oono_brands WHERE wp_internal_brand_status = true limit 1");

    if ($brand && $brand->status === 'ACTIVE') {

    ?>
        <script src="https://staging-apis-v2.oono.ai/static/embedScript.js"></script>
        <script>
            document.querySelectorAll('div[id^="oono-stories-container"]').forEach((div, index) => {
                const config = {
                    containerId: div.id,
                    index,
                    ...JSON.parse(div.getAttribute('data-config'))
                };
                initOonoStories(div, config);
            });
        </script>
<?php
    }
}

// Hook the function to the wp_footer action
add_action('admin_footer', 'oono_enqueue_footer_script');
add_action('wp_footer', 'oono_enqueue_footer_script');



// Enqueue custom JavaScript for AJAX functionality
function oono_enqueue_custom_scripts()
{
    // Enqueue jQuery (if not already included)
    wp_enqueue_script('jquery');

    // Enqueue the custom JavaScript file
    wp_enqueue_script('oono-custom-ajax', plugin_dir_url(__FILE__) . 'js/custom-ajax.js', array('jquery'), null, true);

    // Localize the script with new data
    wp_localize_script('oono-custom-ajax', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'), // URL for AJAX requests
    ));
}
add_action('admin_enqueue_scripts', 'oono_enqueue_custom_scripts');


add_action('wp_ajax_update_brand_status', 'update_brand_status');

function update_brand_status()
{
    global $wpdb;

    // Check if the required parameters are set
    if (isset($_POST['brand_id']) && isset($_POST['wp_internal_brand_status'])) {
        $brand_id = intval($_POST['brand_id']);
        $status = intval($_POST['wp_internal_brand_status']); // Ensure this is either 0 or 1

        // Update the oono_brands table
        $updated = $wpdb->update(
            $wpdb->prefix . 'oono_brands',
            ['wp_internal_brand_status' => $status],
            ['id' => $brand_id]
        );

        // Check if the update was successful
        if ($updated !== false) {
            wp_send_json_success('Brand status updated successfully.');
        } else {
            wp_send_json_error('Failed to update brand status.');
        }
    } else {
        wp_send_json_error('Invalid input.');
    }
}
add_action('wp_ajax_update_brand_info', 'update_brand_info');

function update_brand_info()
{

    if (isset($_POST['brand_access_key'])) {

        $dataFeeds = new DataFeeds();
        $brand_id =  $dataFeeds->fetch_and_save_brand_data($_POST['brand_access_key']);


        if ($brand_id) {

            global $wpdb;
            // Fetch brand data from wp_oono_brands table
            $brand = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}oono_brands WHERE id = %d",
                    $brand_id
                ),
                ARRAY_A
            );

            // Ensure the brand exists before proceeding
            if ($brand) {
                $brand_id = $brand['id']; // Get brand ID

                // Fetch collections data associated with the brand
                $collections_table = $wpdb->prefix . 'oono_brands_collections';
                $collections = $wpdb->get_results(
                    $wpdb->prepare("SELECT * FROM $collections_table WHERE wp_oono_brand_id = %d", $brand_id),
                    ARRAY_A
                );

                // Create the response array
                $response = [
                    'brand' => [
                        'brandId' => $brand['brandId'],
                        'name' => $brand['name'],
                        'storiesCount' => $brand['storiesCount'],
                        'status' => $brand['status']
                    ],
                    'collections' => []
                ];

                // Populate the collections in the response array
                foreach ($collections as $collection) {
                    $response['collections'][] = [
                        'collectionId' => $collection['collectionId'],
                        'name' => $collection['name'],
                        'storiesCount' => $collection['storiesCount'],
                        'status' => $collection['status']
                    ];
                }
                wp_send_json_success($response);
            } else {
                // If no brand found, return an error message
                wp_send_json_success('error');
            }
        } else {
            wp_send_json_success('error');
        }
    }
}
