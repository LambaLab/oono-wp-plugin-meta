jQuery(document).ready(function ($) {
    $('#toggle-checkbox').change(function () {
        var brandId = $(this).data('brand-id');
        var isChecked = $(this).is(':checked') ? 1 : 0; // 1 for true, 0 for false

        // Perform AJAX request to update the database
        $.ajax({
            url: ajaxurl, // WordPress AJAX handler
            type: 'POST',
            data: {
                action: 'update_brand_status', // Custom AJAX action
                brand_id: brandId,
                wp_internal_brand_status: isChecked
            },
            success: function (response) {
                if (response.success) {

                    if (isChecked) {
                        $('#pugin-status').addClass('active').html('Enabled');
                        $('#pugin-status').removeClass('in-active');
                    } else {
                        $('#pugin-status').addClass('in-active').html('Disabled (No more stories visible on you website)');
                        $('#pugin-status').removeClass('active');
                    }
                    console.log('Status updated successfully.');
                } else {
                    console.log('Error updating status: ' + response.data);
                }
            },
            error: function () {
                console.log('AJAX request failed.');
            }
        });
    });
    
});

jQuery(document).ready(function ($) {
    $('#refreshButton').click(function () {

        var brandAccessKey = $('#brand-access-key').val();


    $(`#rotate-icon`).addClass('rotate-icon');
    $(`#resultContainer`).html('');

        // Perform AJAX request to update the database
        $.ajax({
            url: ajaxurl, // WordPress AJAX handler
            type: 'POST',
            data: {
                action: 'update_brand_info', // Custom AJAX action
                brand_access_key: brandAccessKey
            },
            success: function (response) {
              
                console.log(response);

                if(response.data=="error"){
                    $(`#resultContainer`).html('Refresh: Unable to process request.');
                    $(`#rotate-icon`).removeClass('rotate-icon');
                    return false;
                }

                if (response.success) {
                    $('#oono_brand_name').text(response.data.brand.name);

                    if(response.data.brand.status!="ACTIVE"){
                        $('#oono_brand_status').text('* This brand is in-active by oono. Please connect to oono help.');
                    }
                   

                    $('#oono_brand_storiesCount').text(response.data.brand.storiesCount);
                    
                    // Loop through collections and update HTML by matching IDs
                    let collectionsCount = parseInt(response.data.collections.length, 10);
                    let already_collectionCount = parseInt($('#oono_brand_collectionCount').data('value'), 10);

                    if (!isNaN(collectionsCount) && !isNaN(already_collectionCount)) {
                        if (collectionsCount !== already_collectionCount) {
                            console.log("Collection counts differ. Reloading page...");
                            alert("There found difference in collection count. Page needs to be reload to update collections.");
                            location.reload(); // Reload the page if values are not equal
                        }
                    } 
                    
                    
                    response.data.collections.forEach(collection => {
                        const collectionId = collection.collectionId;
                        const name = collection.name;
                        const status = collection.status;
                        const storiesCount = collection.storiesCount;

                        // Find the element with the matching ID and update its text with the status
                        $(`#oono_collection_name_${collectionId}`).text(name);
                       
                        $(`#oono_collection_storiesCount_${collectionId}`).text(storiesCount);
                        if(status!="ACTIVE"){
                             $(`#oono_collection_status_${collectionId}`).text('* This collection is in-active by oono. Please contact to oono help.');
                         //   $(`#oono_collection_status_${collectionId}`).removeClass('in-active');
                        }
                    });
                  
                    console.log('Status updated successfully.');
                } else {
                    console.log('Error updating status: ' + response.data);
                    $(`#resultContainer`).html('Error: Request Failed');
                }
                $(`#rotate-icon`).removeClass('rotate-icon');
            },
            error: function () {
                console.log('AJAX request failed.');
                $(`#resultContainer`).html('Refresh: Request Failed');
                $(`#rotate-icon`).removeClass('rotate-icon');
            }
        });




    });
    $('#refreshButton').trigger('click');
});

