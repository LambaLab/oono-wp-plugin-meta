
jQuery(document).ready(function($) {

    $('.image-card').click(function() {

        var dataValues = JSON.parse($(this).attr('data-values'));
        console.log(dataValues);
        // Get the collectionId from the parsed JSON
        var wp_oono_collection_id = dataValues.wp_oono_collection_id;
       

        var wp_oono_brand_id = dataValues.wp_oono_brand_id;
        var collectionId = dataValues.collectionId;
        var brandSlug = dataValues.brandSlug;
        
        $('#floating-wp_oono_brand_id').val(wp_oono_brand_id);
        $('#floating-collectionId').val(collectionId);
        $('#floating-brandSlug').val(brandSlug);
        $('#floating-wp_oono_collection_id').val(wp_oono_collection_id);

        $('.image-card').removeClass('selected');
        $(this).addClass('selected');
    });

    // Toggle the display of cover size settings
    $('.cover-size-settings-button').click(function() {
        var id = $(this).attr('id').split('-')[3]; // Extract the number from the ID
        $('#cover-size-settings-' + id).toggle(); // Toggle the corresponding div
    });



    $('.floating-settings-button').click(function() {

        var id = $(this).attr('id').split('-')[3]; // Extract the number from the ID
        $('#floating-settings-' + id).toggle(); // Toggle the corresponding div
    });

    $('.postionOfFloating').on('change', function() {

        var selectedClass = $(this).val(); // Get the selected value



        // Remove any previous class (optional, if you only want one color class at a time)
        $('#floatingIcon-icon').removeClass();

        // Add the new class if a valid option is selected
        if (selectedClass) {
            $('#floatingIcon-icon').addClass('ring');
            $('#floatingIcon-icon').addClass(selectedClass);
        }
    });

    $('.floatingStatus').on('change', function() {

       
        var selectedClass = $(this).val(); // Get the selected value

       

        $('#floatingIcon-icon').removeClass('display-none');
        $('#floating-disabled-icon').removeClass();

        // Add the new class if a valid option is selected
        if (selectedClass == 0) {
            $('#floating-disabled-').addClass('ring-iiner2');
            $('#floatingIcon-icon').addClass('display-none');
        }


    });

    $('.copy-icon').click(function() {
        // Get the text inside the <code> element
        var dataValues = $(this).data('values');
  
        var copyElement = dataValues.copyElement;
       
        if(copyElement === "carousel"){
            var selected_key = dataValues.carousel_id;
        }else{
            var selected_key = dataValues.collectionId;
        }

        var shortcodeText = $('#shortcode-text-' + copyElement + selected_key).text();

        // Create a temporary textarea to copy the text
        var tempTextarea = $('<textarea>');
        $('body').append(tempTextarea);
        tempTextarea.val(shortcodeText).select();

        // Copy the text to the clipboard
        document.execCommand('copy');

        // Remove the temporary textarea
        tempTextarea.remove();

        $('#copy-message').html('Copied - ' + shortcodeText);
        // Show the floating "Copied" message
        $('#copy-message').fadeIn();

        // Hide the message after 3 seconds
        setTimeout(function() {
            $('#copy-message').fadeOut();
        }, 3000);


    });
   // Handle tab switching
   $('.tab-links li').click(function(e) {
    e.preventDefault();

    // Remove active class from all tabs
    $('.tab-links li').removeClass('active');
    // Add active class to clicked tab
    $(this).addClass('active');

    // Hide all tab content
    $('.tab-pane').removeClass('active');
    
    // Show the clicked tab's content
    var target = $(this).find('a').attr('href');
    $(target).addClass('active');
});
});
function confirmRemoveBrand() {
    return confirm("Are you sure you want to remove this brand?");
}
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.hash) {
        const target = document.querySelector(window.location.hash);
        if (target) {
            
          // Scroll to the target element if it exists
          target.scrollIntoView({ behavior: 'smooth' });
        } else {
          // If hash exists but the target is not found, scroll to the top
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      } else {
        // If no hash exists, scroll to the top
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
      
  });
  

// Select all forms with the class 'float-settings-form'
document.querySelectorAll('.float-settings-form').forEach((form) => {
    form.addEventListener('submit', function (e) {
        const status = form.querySelector('.floatingStatus').value;
        if (status === '1') {
            const confirmation = confirm(
                'Do you want to proceed?'
            );

            if (!confirmation) {
                e.preventDefault(); // Stop form submission if user cancels
            }
        }
    });
});

               
              
