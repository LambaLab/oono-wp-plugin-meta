<?php

// Dynamically include wp-load.php based on the WordPress installation
if (file_exists(dirname(__FILE__) . '/../../../wp-load.php')) {
    require_once dirname(__FILE__) . '/../../../wp-load.php';
} else {
    require_once dirname(__FILE__) . '/../../../../wp-load.php';
}

// Ensure the user has the correct permissions
if (!is_user_logged_in() || !current_user_can('manage_options')) {
    wp_die('You do not have sufficient permissions to access this page.');
}

// Handle enabling/disabling collection status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_collection'])) {

    $collection_id = intval($_POST['toggle_collection_status']);
    $collection_current_status = sanitize_text_field($_POST['collection_current_status']);

    //$current_collection_status = $wpdb->get_var($wpdb->prepare("SELECT wp_internal_collection_status FROM {$wpdb->prefix}oono_brands_collections WHERE id = %d", $collection_id));

    // Toggle the collection status
    $new_collection_status = ($collection_current_status == true) ? false : true;
    $wpdb->update(
        $wpdb->prefix . 'oono_brands_collections',
        ['wp_internal_collection_status' => $new_collection_status],
        ['id' => $collection_id]
    );

    // Redirect to avoid form re-submission issues
    wp_redirect(admin_url('admin.php?page=oono-brand-connector'));
    exit;
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_float_settings'])) {
// Get the embed_settings table name

global $wpdb;
$brands_table = $wpdb->prefix . 'oono_brands';
$collections_table = $wpdb->prefix . 'oono_brands_collections';
$embed_settings_table = $wpdb->prefix . 'oono_embed_settings';

$response = "failed";
// Sanitize form input data
$collection_id = sanitize_text_field($_POST['collection_id']);

        $type = sanitize_text_field($_POST['type']);
        $status = sanitize_text_field($_POST['status']);
        $positionType = sanitize_text_field($_POST['positionType']);
        $position = sanitize_text_field($_POST['position']);
        $wp_oono_collection_id = sanitize_text_field($_POST['wp_oono_collection_id']);
        $collectionId = sanitize_text_field($_POST['collection_id']);
        $settings_Id = sanitize_text_field($_POST['settings_Id']);

    if ($type == "floating" and !empty($_POST['wp_oono_brand_id'])) {


        if (!empty($settings_Id)) {
            $query = "
                UPDATE $embed_settings_table es
                SET 
                    es.status = %d,
                    es.wp_oono_collection_id = %d,
                    es.collectionId = %s,
                    es.position = %s,
                    es.positionType = %s
                WHERE es.id = %d
            ";
        
            $prepared_query = $wpdb->prepare(
                $query,
                $status,
                $wp_oono_collection_id,
                $collectionId,
                $position,
                $positionType,
                $settings_Id
            );
        
            $result = $wpdb->query($prepared_query);
        
            if ($result === false) {
                error_log('Query failed: ' . $wpdb->last_error);
                $response = "failed";
            } elseif ($result === 0) {
                error_log('No rows updated. Check if the record exists or if the data is identical.');
                $response = "success";
            } else {
                error_log('Record updated successfully.');
                $response = "success";
            }
        } else {
            error_log('Invalid settings_Id. Update aborted.');
        }
        
    }
// Redirect back to the same screen after submission
wp_redirect($_SERVER['HTTP_REFERER']."&icon-update=".$response);
exit();

}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['save_cover_settings']) || isset($_POST['save_float_settings']))) {

    global $wpdb;

    // Get the embed_settings table name
    $brands_table = $wpdb->prefix . 'oono_brands';
    $collections_table = $wpdb->prefix . 'oono_brands_collections';
    $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';

    // Sanitize form input data
    $collection_id = sanitize_text_field($_POST['collection_id']);

    $type = sanitize_text_field($_POST['type']);





    //    $width = attach_px($width);
    //    $height = attach_px($height);

    // Prepare data for updating the embed_settings table
    if ($type == "inPage") {

        $width = !empty($_POST['width']) ? sanitize_text_field($_POST['width']) : '120px';
        $height = !empty($_POST['height']) ? sanitize_text_field($_POST['height']) : '300px';
        $borderRadius = !empty($_POST['borderRadius']) ? sanitize_text_field($_POST['borderRadius']) : '8px';
        // Attach 'px' to width and height if they are numeric
        $width = !empty($width) ? attach_px($width) : '';
        $height = !empty($height) ? attach_px($height) : '';
        $borderRadius = !empty($borderRadius) ? attach_px($borderRadius) : '';

        $embed_data = [
            'style' => json_encode(['width' => $width, 'height' => $height, 'borderRadius' => $borderRadius]),
        ];
    } elseif ($type == "floating") {

        $status = sanitize_text_field($_POST['status']);
        $positionType = sanitize_text_field($_POST['positionType']);
        $position = sanitize_text_field($_POST['position']);

        $embed_data = [
            'status' => $status,
            'positionType' => $positionType,
            'position' => $position,
        ];
    }

    // Check if a record exists with the same collectionId and type
    $existing_record = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $embed_settings_table WHERE collectionId = %s AND type = %s",
            $collection_id,
            $type
        )
    );


    // If the record exists, update it
    if ($existing_record) {

        if ($status==1 and $type == "floating" and !empty($_POST['brand_id'])) {

            // Create and execute the update query
            $query = "
            UPDATE $embed_settings_table es
            INNER JOIN $collections_table c ON es.collectionId = c.collectionId
            INNER JOIN $brands_table b ON c.wp_oono_brand_id = b.id
            SET es.status = 0
            WHERE es.type = 'floating' and b.id = %s
            ";

            $result = $wpdb->query($wpdb->prepare($query, $_POST['brand_id']));
        }

        $result = $wpdb->update(
            $embed_settings_table,
            $embed_data, // data to update
            ['collectionId' => $collection_id, 'type' => $type] // where conditions
        );
    }

    // Redirect back to the same screen after submission
    wp_redirect($_SERVER['HTTP_REFERER']."#section-".$collection_id);
    exit();
}

// Function to append 'px' if the input is numeric
function attach_px($value)
{
    if (is_numeric($value)) {
        return $value . 'px';
    }
    return $value;
}
