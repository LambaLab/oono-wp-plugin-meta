<?php
// include/DataFeeds.php

class DataFeeds
{

    public function __construct()
    {
        // Constructor logic if necessary
    }

    public static function create_oono_tables()
    {
        global $wpdb;
        global $oono_db_version;

        $charset_collate = $wpdb->get_charset_collate();

        $brands_table = $wpdb->prefix . 'oono_brands';
        $collections_table = $wpdb->prefix . 'oono_brands_collections';
        $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';
        $carousels_table = $wpdb->prefix . 'oono_carousels';

        // Create wp_oono_brands table
        $sql1 = "CREATE TABLE IF NOT EXISTS $brands_table (
    id mediumint(9) NOT NULL AUTO_INCREMENT,
    _id varchar(50) NOT NULL,
    brandId varchar(50) NOT NULL,
    slug varchar(255),
    user varchar(50),
    name varchar(255),
    uniqueCode varchar(255),
    logo varchar(255),
    squareLogo varchar(255),
    isPersonal boolean,
    storiesCount int,
    status varchar(50),
    isDefault boolean,
    _v int,
    created_at datetime,
    updated_at datetime,
    wp_internal_brand_status boolean DEFAULT true,
    wp_internal_brand_archive boolean DEFAULT false,
    brand_access_key varchar(255),
    PRIMARY KEY (id),
    UNIQUE KEY unique_id (_id),              -- Unique constraint on _id
    UNIQUE KEY unique_brandId (brandId)      -- Unique constraint on brandId
) $charset_collate;";


        // Create wp_oono_brands_collections table
        $sql2 = "CREATE TABLE IF NOT EXISTS $collections_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        wp_oono_brand_id mediumint(9),
        collectionId varchar(50),
        brand varchar(50),
        brandSlug varchar(50),
        name varchar(255),
        slug varchar(255),
        type varchar(50),
        status varchar(50),
        accessibilityLevel varchar(50),
        isDraft boolean,
        isArchived boolean,
        isTemplate boolean,
        isRtl boolean,
        createdAt datetime,
        updatedAt datetime,
        thumbnail varchar(255),
        cover varchar(255),
        storiesCount int,
        _v int,
        wp_internal_collection_status boolean DEFAULT true,
        PRIMARY KEY  (id),
        UNIQUE KEY unique_id (collectionId)    
    ) $charset_collate;";

        // Create embed_settings table
        $sql3 = "CREATE TABLE IF NOT EXISTS $embed_settings_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        wp_oono_brand_id mediumint(9),
        wp_oono_collection_id mediumint(9),
        collectionId varchar(50),
        brandSlug varchar(50),
        type varchar(50),
        position varchar(50),
        positionType varchar(50),
        status boolean DEFAULT true,
        style json,
        PRIMARY KEY  (id)
    ) $charset_collate;";



        // Create the wp_carousels table
        $sql4 = "CREATE TABLE IF NOT EXISTS $carousels_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wp_oono_brand_id mediumint(9),
    carousel_db_id VARCHAR(255) NOT NULL,
    title VARCHAR(255),
    carousal_key VARCHAR(255),
    brand VARCHAR(255),
    collection_counts mediumint(9),
    enabled TINYINT(1),
    wp_internal_carousel_status boolean DEFAULT true,
    archived TINYINT(1),
    meta_carousel_json LONGTEXT,
    UNIQUE KEY unique_carousel (wp_oono_brand_id, carousel_db_id)
) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
       
    }

    public static function delete_oono_tables()
    {
        global $wpdb;

        $brands_table = $wpdb->prefix . 'oono_brands';
        $collections_table = $wpdb->prefix . 'oono_brands_collections';
        $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';
        $carousels_table = $wpdb->prefix . 'oono_carousels';

        $wpdb->query("DROP TABLE IF EXISTS $brands_table");
        $wpdb->query("DROP TABLE IF EXISTS $collections_table");
        $wpdb->query("DROP TABLE IF EXISTS $embed_settings_table");
        $wpdb->query("DROP TABLE IF EXISTS $carousels_table");
    }
    public function fetch_embed_setting($atts = null, $embed_type = 'button')
    {
        global $wpdb;

        // Prepare the data for fetching from the embed_settings_table
        $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';

        // Base query
        $query = "
            SELECT es.*, bc.status, bc.wp_internal_collection_status, 
                   b.status, b.wp_internal_brand_status
            FROM $embed_settings_table es
            INNER JOIN {$wpdb->prefix}oono_brands_collections bc 
                ON es.collectionId = bc.collectionId
            INNER JOIN {$wpdb->prefix}oono_brands b 
                ON bc.wp_oono_brand_id = b.id
            WHERE es.type = %s
              AND es.status = 1
              AND bc.status = 'ACTIVE'
              AND bc.type = 'PUBLIC'
              AND bc.wp_internal_collection_status = 1
              AND b.status = 'ACTIVE'
              AND b.wp_internal_brand_archive = 0
              AND b.wp_internal_brand_status = 1";

        // If $atts is not null, add collectionId condition
        if (!is_null($atts) && isset($atts['collection_id'])) {
            $query .= " AND es.collectionId = %s";
            $query_params = [$embed_type, $atts['collection_id']];
        } else {
            $query_params = [$embed_type];
        }

        // Execute the query
        if ($embed_type == "floating") {
            $embed_setting = $wpdb->get_results($wpdb->prepare($query, $query_params));
        } else {
            $embed_setting = $wpdb->get_row($wpdb->prepare($query, $query_params));
        }



        return $embed_setting;
    }
    public function fetch_carousel($atts = null)
    {
        global $wpdb;

        // Prepare the data for fetching from the embed_settings_table
        $carousels_table = $wpdb->prefix . 'oono_carousels';

        // Base query
        $query = "
            SELECT oc.*, 
                   b.status, b.wp_internal_brand_status
            FROM $carousels_table oc
            INNER JOIN {$wpdb->prefix}oono_brands b 
                ON oc.wp_oono_brand_id = b.id
            WHERE oc.enabled = 1
              AND oc.wp_internal_carousel_status = 1
              AND oc.archived = 0
              AND b.status = 'ACTIVE'
              AND b.wp_internal_brand_archive = 0
              AND b.wp_internal_brand_status = 1";

        // If $atts is not null, add collectionId condition

        $query .= " AND oc.carousal_key = %s";
        $query_params = [$atts['carousel_key']];

        // Execute the query
        $carousal = $wpdb->get_row($wpdb->prepare($query, $query_params));



        return $carousal;
    }
    public function fetch_and_save_brand_data($access_key)
    {
        global $wpdb;

        // Fetch brand data via API request
        $response = wp_remote_get(OONO_API_URL.'/api/brands/getDetails', [
            'headers' => [
                'brand-access-key' => $access_key
            ]
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        // Decode the API response
        $data = json_decode(wp_remote_retrieve_body($response), true);

        // If the API call is successful, insert/update data
        if ($data['success']) {
            $brand = $data['data'];

            // Prepare the table name
            $table_name = $wpdb->prefix . 'oono_brands';

            // Insert or update brand data using custom SQL query
            $sql = $wpdb->prepare(
                "INSERT INTO $table_name 
    (_id, brandId, slug, user, name, uniqueCode, logo, squareLogo, isPersonal, storiesCount, status, isDefault, _v, wp_internal_brand_archive, created_at, updated_at, brand_access_key) 
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %d, %d, %s, %d, %d, %s, %s, %s, %s) 
    ON DUPLICATE KEY UPDATE 
    slug = VALUES(slug), 
    user = VALUES(user), 
    name = VALUES(name), 
    uniqueCode = VALUES(uniqueCode), 
    logo = VALUES(logo), 
    squareLogo = VALUES(squareLogo), 
    isPersonal = VALUES(isPersonal), 
    storiesCount = VALUES(storiesCount), 
    status = VALUES(status), 
    isDefault = VALUES(isDefault), 
    _v = VALUES(_v),
    wp_internal_brand_archive = 0, 
    created_at = VALUES(created_at), 
    updated_at = VALUES(updated_at), 
    brand_access_key = VALUES(brand_access_key)",
                [
                    $brand['_id'],
                    $brand['brandId'],
                    $brand['slug'],
                    $brand['user'],
                    $brand['name'],
                    $brand['uniqueCode'],
                    $brand['logo'],
                    $brand['squareLogo'],
                    $brand['isPersonal'],
                    $brand['storiesCount'],
                    $brand['status'],
                    $brand['isDefault'],
                    $brand['__v'],
                    0,
                    $brand['createdAt'],
                    $brand['updatedAt'],
                    $access_key
                ]
            );

            // Execute the query
            $wpdb->query($sql);

            // Get the inserted or updated brand ID
            $brand_id = $wpdb->insert_id;

            if (empty($brand_id)) {
                $wpdb->query($sql);
                $brand_id = $wpdb->get_var("SELECT id FROM $table_name WHERE brandId = '{$brand['brandId']}'");
            }

            update_option('oono_brand_id', $brand['brandId']);

            // Insert or update collections data in the wp_oono_brands_collections table
            $counter = 0;
            foreach ($brand['collections'] as $collection) {
                // Prepare the table name
                $collections_table = $wpdb->prefix . 'oono_brands_collections';

                // Insert or update collection data using custom SQL query
                $sql = $wpdb->prepare(
                    "INSERT INTO $collections_table 
    (wp_oono_brand_id, collectionId, brand, brandSlug, name, slug, type, status, accessibilityLevel, 
     isDraft, isArchived, isTemplate, isRtl, createdAt, updatedAt, thumbnail, cover, storiesCount, _v) 
    VALUES (%d, %s, %s, %s, %s, %s, %s, %s, %s, %d, %d, %d, %d, %s, %s, %s, %s, %d, %d)
    ON DUPLICATE KEY UPDATE 
    brand = VALUES(brand),
    brandSlug = VALUES(brandSlug),
    name = VALUES(name),
    slug = VALUES(slug),
    type = VALUES(type),
    status = VALUES(status),
    accessibilityLevel = VALUES(accessibilityLevel),
    isDraft = VALUES(isDraft),
    isArchived = VALUES(isArchived),
    isTemplate = VALUES(isTemplate),
    isRtl = VALUES(isRtl),
    createdAt = VALUES(createdAt),
    updatedAt = VALUES(updatedAt),
    thumbnail = VALUES(thumbnail),
    cover = VALUES(cover),
    storiesCount = VALUES(storiesCount),
    _v = VALUES(_v)",
                    [
                        $brand_id,
                        $collection['collectionId'],
                        $collection['brand'],
                        $brand['slug'],
                        $collection['name'],
                        $collection['slug'],
                        $collection['type'],
                        $collection['status'],
                        $collection['accessibilityLevel'],
                        $collection['isDraft'],
                        $collection['isArchived'],
                        $collection['isTemplate'],
                        $collection['isRtl'],
                        $collection['createdAt'],
                        $collection['updatedAt'],
                        !empty($collection['thumbnail']) ? $collection['thumbnail'] : '',
                        $collection['cover'],
                        $collection['storiesCount'],
                        $collection['__v']
                    ]
                );

                // Execute the query
                $wpdb->query($sql);


                $this->embedSettings($brand['slug'], $collection, $counter);

                $counter++;
            }




            if (isset($brand['carousels'])) {
                $this->save_carousels_to_db($brand['carousels'], $brand_id);
            }

            return $brand_id;
        }

        return false;
    }

    function save_carousels_to_db($carousel_data, $brand_id)
    {
        global $wpdb;

        // Table name
        $table_name = $wpdb->prefix . 'oono_carousels';

        foreach ($carousel_data as $carousel) {
            // Prepare the meta_carousel_json field as a JSON string
            $meta_carousel_json = json_encode($carousel);


            $count = 0;
            if (!empty($carousel["carousalSetting"][0]["collectionIds"])) {
                $count = count($carousel["carousalSetting"][0]["collectionIds"]);
            }


            // Build the SQL query with ON DUPLICATE KEY UPDATE
            $sql = $wpdb->prepare(
                "INSERT INTO $table_name (
                    wp_oono_brand_id,
                    carousel_db_id,
                    title,
                    carousal_key,
                    brand,
                    collection_counts,
                    enabled,
                    archived,
                    meta_carousel_json
                )
                VALUES (%d, %s, %s, %s, %s, %s, %d, %d, %s)
                ON DUPLICATE KEY UPDATE
                    wp_oono_brand_id = VALUES(wp_oono_brand_id),
                    title = VALUES(title),
                    carousal_key = VALUES(carousal_key),
                    brand = VALUES(brand),
                    collection_counts = VALUES(collection_counts),
                    enabled = VALUES(enabled),
                    archived = VALUES(archived),
                    meta_carousel_json = VALUES(meta_carousel_json)
                ",
                $brand_id,                  // wp_oono_brand_id
                $carousel['_id'],           // carousel_db_id
                $carousel['title'],         // title
                $carousel['carousalKey'],   // carousal_key
                $carousel['brand'],         // brand
                $count,
                $carousel['enabled'] ? 1 : 0, // enabled
                $carousel['archived'] ? 1 : 0, // archived
                $meta_carousel_json         // meta_carousel_json
            );

            // Execute the SQL query
            $wpdb->query($sql);
        }
    }



    protected function embedSettings($brand_slug, $collection, $counter)
    {

        global $wpdb;
        $table_name = $wpdb->prefix . 'oono_brands_collections';
        $collection_inserted = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, wp_oono_brand_id FROM $table_name WHERE collectionId = %s",
                $collection['collectionId']
            ),
            ARRAY_A // Fetch result as an associative array
        );

        // Prepare data for inPage
        $data = [
            'wp_oono_brand_id' => $collection_inserted['wp_oono_brand_id'],
            'wp_oono_collection_id' => $collection_inserted['id'],
            'collectionId' => $collection['collectionId'],
            'brandSlug' => $brand_slug,
            'type' => 'inPage',
            'position' => '',
            'positionType' => '',
            'status' => true,
            'style' => json_encode(['width' => '255px', 'height' => 'auto']), // Adjust dimensions as needed
        ];
        $this->saveEmbedSettings($data);


        // Prepare data for button
        $data = [
            'wp_oono_brand_id' => $collection_inserted['wp_oono_brand_id'],
            'wp_oono_collection_id' => $collection_inserted['id'],
            'collectionId' => $collection['collectionId'],
            'brandSlug' => $brand_slug,
            'type' => 'button',
            'position' => '',
            'positionType' => '',
            'status' => true,
            'style' => json_encode([]), // Adjust dimensions as needed
        ];
        $this->saveEmbedSettings($data);


        // Prepare data for float
        if ($counter == 0) {
            $data = [
                'wp_oono_brand_id' => $collection_inserted['wp_oono_brand_id'],
                'wp_oono_collection_id' => $collection_inserted['id'],
                'collectionId' => $collection['collectionId'],
                'brandSlug' => $brand_slug,
                'type' => 'floating',
                'position' => 'top-right',
                'positionType' => 'float',
                'status' => false,
                'style' => json_encode([]), // Adjust dimensions as needed
            ];
            $this->saveEmbedSettings($data);
        }
    }

    public function saveEmbedSettings($data)
    {

        global $wpdb;
        $embed_settings_table = $wpdb->prefix . 'oono_embed_settings';

        // Prepare the SQL query to check if the inpage record exists
        $inpageQuery = $wpdb->prepare(
            "SELECT COUNT(*) FROM $embed_settings_table WHERE collectionId = %s AND type = %s",
            $data['collectionId'],
            $data['type']
        );

        // Check if the record already exists for inPage
        $exists_in_page = $wpdb->get_var($inpageQuery);

        // If it does not exist, insert the record
        if ($exists_in_page == 0) {
            // Insert the data into the table
            $wpdb->insert($embed_settings_table, $data);
        }
    }

    public function getBrand($oono_brand_id)
    {
        global $wpdb;
        $brands_table = $wpdb->prefix . 'oono_brands';
        // Get brand data from the table
        return $brand = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $brands_table WHERE wp_internal_brand_archive = 0 and brandId = %s", $oono_brand_id)
        );
    }
    public function getCollectionCount($brand_id)
    {
        global $wpdb;
        $collection_table = $wpdb->prefix . 'oono_brands_collections';
        return $collection_count = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM $collection_table WHERE  wp_oono_brand_id = %s", $brand_id)
        );
    }
    public function archive_brand_data($oono_brand_id)
    {
        global $wpdb;
        $brands_table = $wpdb->prefix . 'oono_brands';
        $updated = $wpdb->update(
            $wpdb->prefix . 'oono_brands',
            ['wp_internal_brand_archive' => 1],
            ['brandId' => $oono_brand_id]
        );
    }
}
